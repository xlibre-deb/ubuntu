void *alloca(size_t sz)
{
	return NULL;
}
